//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

+ (___FILEBASENAMEASIDENTIFIER___ *)getHeaderFooterViewWithTableView:(UITableView *)tableView;
/**
 configDataSource
 
 @param dic currentCellData
 @param arrData theDataArray
 @param indexPath indexPatch
 */
- (void)config___FILEBASENAMEASIDENTIFIER___WithDic:(NSDictionary *)dic arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath;

@end
