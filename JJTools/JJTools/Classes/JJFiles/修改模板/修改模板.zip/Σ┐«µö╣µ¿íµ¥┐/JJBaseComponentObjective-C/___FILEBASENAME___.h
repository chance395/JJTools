//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/**
 返回一个component
 
 @param superView superView
 @param block 约束block
 @return 默认背景色白色的组件
 */

+(___FILEBASENAMEASIDENTIFIER___ *)MAGetComponentWithSuperView:(UIView *)superView masonrySet:(void (^)(___FILEBASENAMEASIDENTIFIER___ *currentComponent, MASConstraintMaker *make))block;

/**
 传参数
 
 @param infoDic 参数
 */
- (void)setupSubViewsWithInfoDic:(NSDictionary*)infoDic;


@end
