//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic,strong)UILabel     *mTitleLabel;
@property (nonatomic,strong)UIImageView *mConentImv;
@property (nonatomic,strong)UIButton    *mActionBtn;
@property (nonatomic,strong)UIView      *mBackView;

@end


@implementation ___FILEBASENAMEASIDENTIFIER___

+(___FILEBASENAMEASIDENTIFIER___ *)MAGetComponentWithSuperView:(UIView *)superView masonrySet:(void (^)(___FILEBASENAMEASIDENTIFIER___ *currentComponent, MASConstraintMaker *make))block
{
    ___FILEBASENAMEASIDENTIFIER___ *component =[[___FILEBASENAMEASIDENTIFIER___ alloc]init];
    component.backgroundColor =[UIColor whiteColor];
    [superView addSubview:component];
    
    [component mas_makeConstraints:^(MASConstraintMaker *make) {
        if (block)
        {
            block (component,make);
        }
    }];
    
    [component setupSubViews];
    return component;
}

- (void)setupSubViews
{
    
    self.conentImv =[UIImageView MAGetImageViewWith:@"" superView:self masonrySet:^(UIImageView *currentImageView, MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(0);
        make.top.equalTo(self.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    self.titleLabel =[UILabel MAGetLabelWithFont:FONT(14) text:@"" textColor:[UIColor whiteColor] textAlignment:NSTextAlignmentLeft superView:self masonrySet:^(UILabel *currentLabel, MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(0);
        make.top.equalTo(self.mas_top).mas_offset(0);
        
    }];
    
    //case 1 Image
    self.actionBtn =[UIButton MAGetButtonWithImage:@"" superView:self target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(0);
        make.top.equalTo(self.mas_top).mas_offset(0);
        
    }];
    
    //case 2  title
    self.actionBtn =[UIButton MAGetButtonWithTitle:@"" font:FONT(12) textColor:[UIColor whiteColor] backGroundColor:[UIColor whiteColor] corners:4 superView:self target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(0);
        make.top.equalTo(self.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    self.backView =[UIView MAGetViewWithBackgroundColor:[UIColor whiteColor] superView:self masonrySet:^(UIView *currentView, MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(0);
        make.top.equalTo(self.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
}


#pragma mark -public
- (void)setupSubViewsWithInfoDic:(NSDictionary*)infoDic
{
    self.titleLabel =infoDic[@"title"];
    self.conentImv.image =[UIImage imageNamed:infoDic[@"icon"]];
    //case1
    [self.actionBtn setImage:[UIImage imageNamed:infoDic[@"imageName"]] forState:UIControlStateNormal];
    //case2
    [self.actionBtn setTitle:infoDic[@"btnTitle"] forState:UIControlStateNormal];
    
}

#pragma mark -action
- (void)btnClickAction:(UIButton*)sender
{
    
}



@end
