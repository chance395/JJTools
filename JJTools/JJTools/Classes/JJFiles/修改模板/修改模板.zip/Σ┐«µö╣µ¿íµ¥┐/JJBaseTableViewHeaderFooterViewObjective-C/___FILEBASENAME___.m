//___FILEHEADER___

#import "JJBaseHeader.h"
#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic,strong)UILabel     *mTitleLabel;
@property (nonatomic,strong)UIImageView *mConentImv;
@property (nonatomic,strong)UIButton    *mActionBtn;
@property (nonatomic,strong)UIView      *mBackView;

@end


@implementation ___FILEBASENAMEASIDENTIFIER___

+ (___FILEBASENAMEASIDENTIFIER___ *)getHeaderFooterViewWithTableView:(UITableView *)tableView
{
    static NSString * ID = @"___FILEBASENAMEASIDENTIFIER___";
    ___FILEBASENAMEASIDENTIFIER___ * headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    
    if ( !headerView )
    {
        headerView = [[___FILEBASENAMEASIDENTIFIER___ alloc]initWithReuseIdentifier:ID];
        [headerView setupSubViews];
       
    }
    
    return headerView;
    
}

- (void)setupSubViews
{
    self.contentView.backgroundColor = [UIColor whiteColor];
    
    self.mConentImv =[UIImageView MAGetImageViewWith:@"" superView:self.contentView masonrySet:^(UIImageView *currentImageView, MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).mas_offset(0);
        make.top.equalTo(self.contentView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    self.mTitleLabel =[UILabel MAGetLabelWithFont:FONT(14) text:@"" textColor:[UIColor whiteColor] textAlignment:NSTextAlignmentLeft superView:self.contentView masonrySet:^(UILabel *currentLabel, MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).mas_offset(0);
        make.top.equalTo(self.contentView.mas_top).mas_offset(0);
        
    }];
    
    //case 1 Image
    self.mActionBtn =[UIButton MAGetButtonWithImage:@"" superView:self.contentView target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).mas_offset(0);
        make.top.equalTo(self.contentView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    //case 2  title
    self.mActionBtn =[UIButton MAGetButtonWithTitle:@"" font:FONT(12) textColor:[UIColor whiteColor] backGroundColor:[UIColor whiteColor] corners:4 superView:self.contentView target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).mas_offset(0);
        make.top.equalTo(self.contentView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    self.mBackView =[UIView MAGetViewWithBackgroundColor:[UIColor whiteColor] superView:self.contentView masonrySet:^(UIView *currentView, MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).mas_offset(0);
        make.top.equalTo(self.contentView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    

    
}
#pragma mark -Getter


#pragma mark -Setter

#pragma mark -public
- (void)config___FILEBASENAMEASIDENTIFIER___WithDic:(NSDictionary *)dic arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath
{
    self.mTitleLabel.text =dic[@"title"];
    self.mConentImv.image =[UIImage imageNamed:dic[@"icon"]];
    //case1
    [self.mActionBtn setImage:[UIImage imageNamed:dic[@"imageName"]] forState:UIControlStateNormal];
    //case2
    [self.mActionBtn setTitle:dic[@"btnTitle"] forState:UIControlStateNormal];
    
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

#pragma mark -btnAction

- (void)btnClickAction:(UIButton*)sender
{
  
    
}

- (void)awakeFromNib
{
    [super awakeFromNib];
   
}



@end
