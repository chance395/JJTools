//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView           * tbvMain;
@property (nonatomic, strong) NSMutableArray        * arrDataSource;

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"模板";
    [self configSubViews];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self loadDataSource];
}


- (void)dealloc
{
    
}

#pragma mark - Getter

- (UITableView *)tbvMain
{
    if (!_tbvMain) {
        _tbvMain = [[JJBaseTableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
        _tbvMain.delegate = self;
        _tbvMain.dataSource = self;
        _tbvMain.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbvMain.backgroundColor=[UIColor xh_pageBackGroundColor];
        
    }
    
    return _tbvMain;
}
#pragma mark - Setter

#pragma mark - Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.arrDataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    return 0.1;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    
    return [UIView new];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    JJBaseTableViewCell *aCell = [JJBaseTableViewCell getCellWithTableView:tableView];
    if(self.arrDataSource.count >0)
    {
        [aCell configJJBaseTableViewCellWithDic:self.arrDataSource[indexPath.row] arrdata:self.arrDataSource indexPath:indexPath];
    }
    return aCell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 111.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
}
#pragma mark - Public


#pragma mark - Private
- (void)configSubViews {
    
    [self.view addSubview:self.tbvMain];
    
}

- (void)loadDataSource
{
   
    
}



#pragma mark - Override
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

#pragma mark - action



@end
