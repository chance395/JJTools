//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()
/**
 add private property
 */
@end

@implementation ___FILEBASENAMEASIDENTIFIER___

+(___FILEBASENAMEASIDENTIFIER___*)MAGetComponentWithBackgroundColor:(UIColor*)viewColor paramDic:(NSDictionary*)paramDic superView:(UIView*)superView masonrySet:(void(^)(UIView*currentView,MASConstraintMaker*make))block
{
    ___FILEBASENAMEASIDENTIFIER___ *component =[[___FILEBASENAMEASIDENTIFIER___ alloc]init];
    if (viewColor) {
        component.backgroundColor =viewColor;
    }
    [superView addSubview:component];
    [component mas_makeConstraints:^(MASConstraintMaker *make) {
        if (block) {
            block(component,make);
        }
    }];
    [component setupSubViewsWithParamDic:paramDic];
    
    return component;
}

-(void)setupSubViewsWithParamDic:(NSDictionary*)dic
{
    self.contentView =[UIView MAGetUIViewWithHexBackgroundColor:@"#DBDBDB" corner:4 superView:self masonrySet:^(UIView *currentView, MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    self.titleLabel =[UILabel MAGetLabelWithFont:FONT(18) text:dic[@"title"] textColor:[UIColor JJColorWithHexStr:@"#323232"] textAlignment:NSTextAlignmentLeft superView:self masonrySet:^(UILabel *currentLabel, MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.equalTo(self.mas_top).mas_offset(12);
        
    }];
    
    self.subTitleLabel =[UILabel MAGetLabelWithFont:FONT(12) text:dic[@"subTitle"] textColor:[UIColor JJColorWithHexStr:@"#656565"] textAlignment:NSTextAlignmentRight superView:self masonrySet:^(UILabel *currentLabel, MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).mas_offset(15);
        make.left.equalTo(self.titleLabel);
        make.bottom.equalTo(self.contentView).mas_offset(11);
        make.right.equalTo(self.contentView).mas_offset(0);
        make.centerX.equalTo(self.contentView);
        make.centerY.equalTo(self.contentView);
    }];
    
    self.iconImageView =[UIImageView MAGetImageViewWith:@"" superView:self masonrySet:^(UIImageView *currentImageView, MASConstraintMaker *make) {
        make.top.equalTo(self.subTitleLabel.mas_bottom).mas_offset(15);
        make.left.equalTo(self.subTitleLabel);
        make.bottom.equalTo(self.contentView).mas_offset(11);
        make.right.equalTo(self.contentView).mas_offset(0);
    }];
    
    self.btn =[UIButton MAGetButtonWithTitle:@"" font:FONT(13) hexColorStr:@"" hexBackGroundColor:nil corners:3 superView:self target:nil action:nil masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).mas_offset(15);
        make.left.equalTo(self.iconImageView);
        make.bottom.equalTo(self.contentView).mas_offset(11);
        make.right.equalTo(self.contentView).mas_offset(0);
    }];
    
}


@end
