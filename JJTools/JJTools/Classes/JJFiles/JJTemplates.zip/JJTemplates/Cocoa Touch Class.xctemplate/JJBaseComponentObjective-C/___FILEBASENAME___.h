//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___
#import "Masonry.h"
@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

@property (nonatomic, strong) UIView                      * contentView;
@property (nonatomic, strong) UIImageView                 * iconImageView;
@property (nonatomic, strong) UILabel                     * titleLabel;
@property (nonatomic, strong) UILabel                     * subTitleLabel;
@property (nonatomic, strong) UIButton                    * btn;

/**
 return a custom component
 
 @param viewColor BackgroundColor
 @param paramDic paramDic
 @param superView superview
 @param block block
 @return component
 */
+(___FILEBASENAMEASIDENTIFIER___*)MAGetComponentWithBackgroundColor:(UIColor*)viewColor paramDic:(NSDictionary*)paramDic superView:(UIView*)superView masonrySet:(void(^)(UIView*currentView,MASConstraintMaker*make))block;

@end
