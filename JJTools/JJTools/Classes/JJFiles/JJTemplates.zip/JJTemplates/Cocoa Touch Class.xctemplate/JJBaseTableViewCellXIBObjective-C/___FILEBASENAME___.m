//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@end

#pragma mark -public
@implementation ___FILEBASENAMEASIDENTIFIER___

+ (___FILEBASENAMEASIDENTIFIER___ *)getCellWithTableView:(UITableView *)tableView
{
    static NSString * ID = @"___FILEBASENAMEASIDENTIFIER___";
    ___FILEBASENAMEASIDENTIFIER___ * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if ( !cell )
    {
        /** remember set the Identifie in xib
         */
        cell = [[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil] firstObject];
        [cell setupSubViews];
        cell.backgroundColor = [UIColor whiteColor];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (void)config___FILEBASENAMEASIDENTIFIER___WithDic:(NSDictionary *)dic arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath
{
    
}

- (CGFloat)getCellHeight
{
    return 0;
}

#pragma mark -private
- (void)setupSubViews
{
   
}
#pragma mark -Getter


#pragma mark -Setter


#pragma mark--override
- (void)layoutSubviews
{
    [super layoutSubviews];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
}


#pragma mark -btnAction or delegate


@end
