//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - LifeCycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self configSubViews];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
 
}

- (void)dealloc
{
    
}

#pragma mark - Getter

#pragma mark - Setter

#pragma mark - Public

#pragma mark - Private

-(void)configSubViews
{
    
}

#pragma mark - Override

#pragma mark - action

#pragma mark - Delegate


@end
