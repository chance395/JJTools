//___FILEHEADER___

#import "___FILEBASENAME___.h"
@interface ___FILEBASENAMEASIDENTIFIER___ ()
/**
 add private property
 */
@end
@implementation ___FILEBASENAMEASIDENTIFIER___
#pragma mark--init
- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil] firstObject];
        [self addSubview:self.selfView];
        self.selfView.frame =frame;
        self.frame =frame;
    }
    return self;
}

#pragma mark--private
-(void)configSubViewsWithData:(NSDictionary*)data
{
    
}


#pragma mark--override
- (void)drawRect:(CGRect)rect {
    
}

@end
