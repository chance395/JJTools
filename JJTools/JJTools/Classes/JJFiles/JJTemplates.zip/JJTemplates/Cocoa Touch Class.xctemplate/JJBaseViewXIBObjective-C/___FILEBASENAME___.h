//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___
/**
 initSubVIew
 
 @param data dic
 */
-(void)configSubViewsWithData:(NSDictionary*)data;
@end

NS_ASSUME_NONNULL_END
