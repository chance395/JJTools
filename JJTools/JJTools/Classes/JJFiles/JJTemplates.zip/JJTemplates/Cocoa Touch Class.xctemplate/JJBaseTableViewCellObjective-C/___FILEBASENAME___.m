//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic, strong) UILabel     * titleLabel;
@property (nonatomic, strong) UIImageView * conentImv;
@property (nonatomic, strong) UIButton    * actionBtn;
@property (nonatomic, strong) UIView      * backView;

@end

#pragma mark -public
@implementation ___FILEBASENAMEASIDENTIFIER___

+ (___FILEBASENAMEASIDENTIFIER___ *)getCellWithTableView:(UITableView *)tableView
{
    static NSString * ID = @"___FILEBASENAMEASIDENTIFIER___";
    ___FILEBASENAMEASIDENTIFIER___ * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if ( !cell )
    {
        cell = [[___FILEBASENAMEASIDENTIFIER___ alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        [cell setupSubViews];
        cell.backgroundColor = [UIColor whiteColor];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (void)config___FILEBASENAMEASIDENTIFIER___WithData:(id )data arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath
{
    
}

- (CGFloat)getCellHeight
{
    return 0;
}

#pragma mark -private
- (void)setupSubViews
{
    UIView *superView =self.contentView;
    
    self.backView = [UIView MAGetUIViewWithBackgroundColor:[UIColor JJRandomColor] corner:4 superView:superView masonrySet:^(UIView *currentView, MASConstraintMaker *make) {
        make.edges.equalTo(superView);
    }];
    
    
    self.conentImv =[UIImageView MAGetImageViewWith:@"" superView:superView masonrySet:^(UIImageView *currentImageView, MASConstraintMaker *make) {
        make.left.equalTo(superView.mas_left).mas_offset(0);
        make.top.equalTo(superView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    self.titleLabel =[UILabel MAGetLabelWithFont:FONT(14) text:@"" textColor:[UIColor JJRandomColor] textAlignment:NSTextAlignmentLeft superView:superView masonrySet:^(UILabel *currentLabel, MASConstraintMaker *make) {
        make.left.equalTo(superView.mas_left).mas_offset(0);
        make.top.equalTo(superView.mas_top).mas_offset(0);
        
        
    }];
    
    //case 1 Image
    self.actionBtn =[UIButton MAGetButtonWithImage:@"" superView:superView target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(superView.mas_left).mas_offset(0);
        make.top.equalTo(superView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
    //case 2  title
    self.actionBtn =[UIButton MAGetButtonWithTitle:@"" font:FONT(12) textColor:[UIColor whiteColor] backGroundColor:[UIColor whiteColor] corners:4 superView:superView target:self action:@selector(btnClickAction:) masonrySet:^(UIButton *currentBtn, MASConstraintMaker *make) {
        make.left.equalTo(superView.mas_left).mas_offset(0);
        make.top.equalTo(superView.mas_top).mas_offset(0);
        make.width.mas_equalTo(0);
        make.height.mas_equalTo(0);
        
    }];
    
}
#pragma mark -Getter


#pragma mark -Setter


#pragma mark--override
- (void)layoutSubviews
{
    [super layoutSubviews];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
}


#pragma mark -btnAction or delegate

- (void)btnClickAction:(UIButton*)sender
{
    
    
}
@end
