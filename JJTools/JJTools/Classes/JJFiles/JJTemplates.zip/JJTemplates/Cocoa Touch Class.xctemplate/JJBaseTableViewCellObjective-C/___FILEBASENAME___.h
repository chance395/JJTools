//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/**
 init cell
 
 @param tableView tableView
 @return cell
 */

+ (___FILEBASENAMEASIDENTIFIER___ *)getCellWithTableView:(UITableView *)tableView;
/**
 configDataSource
 
 @param data currentCellData
 @param arrData theDataArray
 @param indexPath indexPatch
 */
- (void)config___FILEBASENAMEASIDENTIFIER___WithData:(id )data arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath;

/**
 cell height
 
 @return height
 */
-(CGFloat)getCellHeight;

@end
