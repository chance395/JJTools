//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/**
 init collection the method is needed
 
 @param frame frame
 @return cell
 */
- (instancetype)initWithFrame:(CGRect)frame;

/**
 cofig cell
 
 @param dic dic
 @param arrData data
 @param indexPath index
 */
- (void)config___FILEBASENAMEASIDENTIFIER___WithDic:(NSDictionary *)dic arrdata:(NSMutableArray *)arrData indexPath:(NSIndexPath *)indexPath;

/**
 HeaderFooterView height
 
 @return height
 */
-(CGFloat)getCellHeight;

@end
