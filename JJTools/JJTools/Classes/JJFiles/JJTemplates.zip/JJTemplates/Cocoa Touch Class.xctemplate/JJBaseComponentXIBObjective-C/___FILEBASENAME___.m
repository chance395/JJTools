//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()
/**
 add private property
 */
@end

@implementation ___FILEBASENAMEASIDENTIFIER___

+(___FILEBASENAMEASIDENTIFIER___*)MAGetComponentWithBackgroundColor:(UIColor*)viewColor paramDic:(NSDictionary*)paramDic superView:(UIView*)superView masonrySet:(void(^)(UIView*currentView,MASConstraintMaker*make))block
{
    ___FILEBASENAMEASIDENTIFIER___ *component =[[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil] firstObject];
    if (viewColor) {
        component.backgroundColor =viewColor;
    }
    [superView addSubview:component];
    [component mas_makeConstraints:^(MASConstraintMaker *make) {
        if (block) {
            block(component,make);
        }
    }];
    [component setupSubViewsWithParamDic:paramDic];
    
    return component;
}

-(void)setupSubViewsWithParamDic:(NSDictionary*)dic
{
    
    
}


@end
