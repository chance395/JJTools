//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___
#import "Masonry.h"
@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/**
 return a custom component
 
 @param viewColor BackgroundColor
 @param paramDic paramDic
 @param superView superview
 @param block block
 @return component
 */
+(___FILEBASENAMEASIDENTIFIER___*)MAGetComponentWithBackgroundColor:(UIColor*)viewColor paramDic:(NSDictionary*)paramDic superView:(UIView*)superView masonrySet:(void(^)(UIView*currentView,MASConstraintMaker*make))block;

@end
