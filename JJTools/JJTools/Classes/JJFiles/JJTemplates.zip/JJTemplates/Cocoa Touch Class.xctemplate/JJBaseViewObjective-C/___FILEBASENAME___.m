//___FILEHEADER___

#import "___FILEBASENAME___.h"
@interface ___FILEBASENAMEASIDENTIFIER___ ()

@property (nonatomic, strong) UILabel     * titleLabel;
@property (nonatomic, strong) UIView      * underLineView;
@property (nonatomic, strong) UITextField * InputTextField;
@property (nonatomic, strong) UIImageView * iConImage;
@property (nonatomic, strong) UIButton    * clickBtn;

@implementation ___FILEBASENAMEASIDENTIFIER___


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupSubViews];
    }
    return self;
}

#pragma mark--initView
-(void)setupSubViews
{
    
}

#pragma mark--override
- (void)drawRect:(CGRect)rect {
    // Drawing code
}

@end
