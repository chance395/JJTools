//___FILEHEADER___

#import "___FILEBASENAME___.h"
#import "JJBaseTableViewCell.h"
#import "JJBaseTableView.h"
#import "XHFavourOrderCollectionHeaderView.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) JJBaseTableView           * tbvMain;
@property (nonatomic, strong) XHFavourOrderCollectionHeaderView *headerView;
@property (nonatomic, strong) NSMutableArray            * showArr;
@property (nonatomic, assign) NSUInteger                   pageNum;
@end

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"模板";
    [self cm_addRightNavigationBarButtonItemWithTitle:@"Title"];
    [self configSubViews];
    [self loadDataSource];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}


- (void)dealloc
{
    
}

#pragma mark - Getter

- (JJBaseTableView *)tbvMain
{
    if (!_tbvMain) {
        _tbvMain = [[JJBaseTableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-kNavBarAndStatusBarHeight) style:UITableViewStylePlain];
        _tbvMain.delegate = self;
        _tbvMain.dataSource = self;
        _tbvMain.tableHeaderView =self.headerView;
        _tbvMain.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbvMain.backgroundColor=[UIColor xh_pageBackGroundColor];
        
    }
    
    return _tbvMain;
}

-(XHFavourOrderCollectionHeaderView *)headerView
{
    if (!_headerView) {
        _headerView =[[XHFavourOrderCollectionHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 200)];
    }
    return _headerView;
}

-(NSMutableArray *)showArr
{
    if (!_showArr) {
        _showArr =[NSMutableArray array];
    }
    return _showArr;
}

#pragma mark - Setter

#pragma mark - Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.showArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    return 0.1;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    
    return [UIView new];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    JJBaseTableViewCell *aCell = [JJBaseTableViewCell getCellWithTableView:tableView];
    if(self.showArr.count >0)
    {
        [aCell configJJBaseTableViewCellWithData:self.showArr[indexPath.row] arrdata:nil indexPath:indexPath];
    }
    return aCell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 111.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
}
#pragma mark - Public


#pragma mark - Private

- (void)reloadDataView
{
  void(^UpdateUIBlock)(void) = [^{
    JJBaseTableView * tableView = self.tbvMain;
        
    [UIView setAnimationsEnabled:NO];
        
    [tableView reloadData];
        
    [UIView setAnimationsEnabled:YES];
    } copy];
    
    if ([NSThread isMainThread])
    {
        UpdateUIBlock();
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), UpdateUIBlock);
    }
}

- (void)configSubViews {
    
    [self.view addSubview:self.tbvMain];
    
    @weakify(self);
    [RACObserve(self, showArr)subscribeNext:^(id x) {
        @strongify(self);
        [self reloadDataView];
        
    }];
}

- (void)loadDataSource
{
    self.pageNum =1;
    self.tbvMain.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewDataSoure)];
    
    self.tbvMain.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDataSoure)];
    
    [self.tbvMain.mj_header beginRefreshing];
}

-(void)loadNewDataSoure
{
    self.pageNum =1;
    [self requestData];
    
}
-(void)loadMoreDataSoure
{
    self.pageNum ++;
    [self requestData];
}

-(void)requestData
{
    [self.resultStatusView showLoading];
//    @weakify(self);
//    [[XHSyncHelper shareInstance]getVisitPlanMangementWitPageNo:[NSString stringWithFormat:@"%ld",self.pageNum] pageSize:kVisitPageSize station:self.stationCode success:^(id data) {
//        @strongify(self);
//        [self.resultStatusView dissmiss];
//        if (self.pageNum ==1) {
//            [self.modelArray removeAllObjects];
//        }
//        [self.modelArray addObjectsFromArray: [NSMutableArray arrayWithArray:[visitPlanMangementModel mj_objectArrayWithKeyValuesArray:data]]];
//        [self.tableView reloadData];
//        [self.tableView.mj_header endRefreshing];
//        [self.tableView.mj_footer endRefreshing];
//
//    } error:^(id data) {
//        [self.tableView.mj_header endRefreshing];
//        [self.tableView.mj_footer endRefreshing];
//        [self.resultStatusView showSuccess:NO withMessage:ErrorRequest];
//    }];
}

#pragma mark - Override
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(void)goToBack
{
    [self cm_popViewController];
}

-(void)cm_rightBarButtonItemAction:(UIBarButtonItem *)barButton
{
    
}

#pragma mark - action



@end
